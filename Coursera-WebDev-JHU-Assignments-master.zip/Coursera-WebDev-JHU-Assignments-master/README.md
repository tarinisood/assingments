# Coursera-WebDev-JHU-Assignments

###HTML, CSS, JavaScript for Web Developers
####Johns Hopkins University
#####Coursera
<hr>
This repository contains my solutions to the Module - 2, 3, 4 Coding Assignments for the course HTML, CSS, JavaScript for Web Developers by Johns Hopkins University on Coursera. <br>

<hr>
<b>Assignment Links:</b> <br>
- [Module 2 Assignment](http://goo.gl/4Blt4G) <br>
- [Module 3 Assignment](http://bit.ly/1mKZzJ5) <br>
- [Module 4 Assignment](http://bit.ly/21StgWz) <br>
- [Module 5 Assignment](http://bit.ly/1UWgPJ1) <br>
Mockup illustrations are present in the Assignment documents.
<br>

<b>Solution Links:</b> <br>
- [Module 2 Solution](http://faheemzunjani.github.io/Coursera-WebDev-JHU-Assignments/module-2-solution/index.html) <br>
- [Module 3 Solution](http://faheemzunjani.github.io/Coursera-WebDev-JHU-Assignments/module-3-solution/index.html) <br>
- [Module 4 Solution](http://faheemzunjani.github.io/Coursera-WebDev-JHU-Assignments/module-4-solution/index.html) <br>
- [Module 5 Solution](http://faheemzunjani.github.io/Coursera-WebDev-JHU-Assignments/module-5-solution/index.html) <br>